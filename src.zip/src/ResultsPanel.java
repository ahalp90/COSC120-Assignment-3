import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Panel showing the results screen.
 * <p>Shows a scrollable list of MenuItemPanels that match the user's search criteria,
 * or the full menu if no matches were found.
 * <p>Allows the user to select >=1 items via checkboxes and then proceed to the order creation view
 * or return to the search view.
 */
public final class ResultsPanel {
    private final JPanel corePanel;
    private final JLabel titleLabel;
    private final JPanel itemsListPanel;
    private final JButton proceedButton;
    private final JButton backButton;

    private ResultsPanelListener listener;

    //Store the MenuItemPanels to display.
    private final List<MenuItemPanel> menuItemPanels = new ArrayList<>();

    /**
     * Constructor for the search results panel.
     * <p>Initialises all GUI components and composes final layout.
     */
    public ResultsPanel(){
        corePanel = new JPanel(new BorderLayout(10,10));
        corePanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        titleLabel = new JLabel("Search Results", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));

        itemsListPanel = new JPanel();
        itemsListPanel.setLayout(new BoxLayout(itemsListPanel, BoxLayout.Y_AXIS));

        JScrollPane scrollPane = new JScrollPane(itemsListPanel);
        scrollPane.setBorder(BorderFactory.createEtchedBorder());
        //Default scroll is so slow! Fix from:
        //https://stackoverflow.com/questions/10119587/how-to-increase-the-slow-scroll-speed-on-a-jscrollpane
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        backButton = new JButton("Back to Search");
        proceedButton = new JButton("Confirm Selection and Order");

        JPanel bottomButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomButtonPanel.add(backButton);
        bottomButtonPanel.add(proceedButton);

        corePanel.add(titleLabel, BorderLayout.NORTH);
        corePanel.add(scrollPane, BorderLayout.CENTER);
        corePanel.add(bottomButtonPanel, BorderLayout.SOUTH);

        addActionListeners();
    }

    /**
     * Sets up ActionListeners for the "Back to Search" and "Confirm Selection" buttons.
     * <p>These listeners delegate decisions about the specific response to the
     * registered ResultsPanelListener (i.e. OrderGui)
     */
    private void addActionListeners() {

        backButton.addActionListener(e -> {
            //Don't handle this, just do a noisy crash to facilitate debugging
            if (listener==null) throw new IllegalStateException("Listener is null; results panel buttons cannot function.");

            listener.onBackButtonPressed();
        });

        proceedButton.addActionListener(e -> {
            //Don't handle this, just do a noisy crash to facilitate debugging
            if (listener==null) throw new IllegalStateException("Listener is null; results panel buttons cannot function.");

            List<MenuItem> selectedItems = getSelectedItems();
            //show dialog indicating no selection
            if (selectedItems.isEmpty()) {
                JOptionPane.showMessageDialog(
                        corePanel,
                        "Please select at least one item to add to your order.",
                        "No Items Selected",
                        JOptionPane.WARNING_MESSAGE);
            } else {
                //go to next view
                listener.onProceedToDetails(selectedItems);
            }
        });
    }

    /**
     * Clears any previous search results and shows a new list of MenuItems.
     * <p>Creates a new MenuItemPanel for each item in the provided List and adds it to the scrollable view.
     * <p>Also updates the title of the panel to indicate search matches/lack thereof.
     * <p>After adding the new components, repaints and revalidates to ensure correct UI display and proportions.
     * @param items List of MenuItems to display
     * @param title String of the title text
     */
    public void displayItems(List<MenuItem> items, String title) {
        //CLEAR ANY ITEMS FROM A PREVIOUS SEARCH
        itemsListPanel.removeAll();
        menuItemPanels.clear();
        titleLabel.setText(title);

        if (items.isEmpty()) {
            JLabel noItemsLabel = new JLabel("No Items to Display.", SwingConstants.CENTER);
            itemsListPanel.add(noItemsLabel);
        } else {
            for (MenuItem item : items) {
                MenuItemPanel itemPanel = new MenuItemPanel(item);
                menuItemPanels.add(itemPanel);
                itemsListPanel.add(itemPanel.getCorePanel());
                itemsListPanel.add(Box.createRigidArea(new Dimension(0, 5))); //Add a small separator
            }
        }
        //Explicit instruction to rejig Component proportions to fit new Components and actually show them on screen.
        this.corePanel.revalidate();
        this.corePanel.repaint();
    }

    /**
     * Getter for the main Panel containing all Components
     * @return core JPanel for this view
     */
    public JPanel getCorePanel() {return this.corePanel;}

    /**
     * Register the listener that will handle this Panel's events and data
     * <p>This panel uses a single listener because it's designed to send events directly back to its parent container
     * @param listener ResultsPanelListener interface, though ultimately it's the OrderGui listening.
     */
    public void setResultsPanelListener(ResultsPanelListener listener) {
        this.listener = listener;
    }

    /**
     * Scan all displayed MenuItemPanels and return a List of those selected.
     * @return List of MenuItems selected by the user; List will be empty if none are selected.
     */
    private List<MenuItem> getSelectedItems() {
        List<MenuItem> selected = new ArrayList<>();
        for (MenuItemPanel panel : menuItemPanels) {
            if (panel.isSelected()) {
                selected.add(panel.getMenuItem());
            }
        }
        return selected;
    }

}
